import unittest
from eva_omega.maxcut import exact_maxcut, greedy_maxcut, local_search_maxcut, cut_value
from eva_omega.selector import AdaptiveSelector

class TestCore(unittest.TestCase):
    def test_exact_triangle(self):
        result = exact_maxcut(3, [(0,1,1), (1,2,1), (0,2,1)])
        self.assertEqual(result["cut_value"], 2)
        self.assertEqual(result["evaluations"], 4)

    def test_cut_value(self):
        self.assertEqual(cut_value((0,1,0), [(0,1,2), (1,2,3), (0,2,5)]), 5)

    def test_local_search_valid(self):
        edges = [(0,1,2), (1,2,3), (0,2,5)]
        result = local_search_maxcut(3, edges, [0,0,0])
        self.assertGreaterEqual(result["cut_value"], 0)

    def test_selector_calibration_and_history(self):
        selector = AdaptiveSelector(["a", "b"])
        self.assertEqual(selector.next_strategy(), "a")
        self.assertEqual(selector.next_strategy(), "b")
        selector.update("a", 0.1, 5, 10)
        selector.update("b", 0.2, 6, 20)
        self.assertEqual(selector.next_strategy(), "a")

    def test_greedy_result_is_feasible(self):
        edges = [(0,1,2), (1,2,3)]
        result = greedy_maxcut(3, edges)
        self.assertEqual(len(result["bits"]), 3)
        self.assertGreaterEqual(result["cut_value"], 0)

if __name__ == "__main__":
    unittest.main()
