# Protocolo científico v0.2

## Objetivo 1
Evaluar si un selector adaptativo que elige entre estrategias clásicas puede ofrecer una combinación competitiva de calidad y coste en instancias pequeñas de MaxCut.

## Hipótesis predefinida
H1: el gap medio de EVA-Ω no excede el gap medio de la mejor estrategia fija por más de 0.02 (dos puntos porcentuales) en el conjunto de 30 instancias. H0: excede ese margen.
Esta tolerancia es una decisión de ingeniería para el primer piloto, no un umbral universal.

## Métrica primaria
Gap relativo: `(C_opt - C_method) / max(C_opt, epsilon)`.
También se registra tasa de óptimo, número de evaluaciones y tiempo de pared.

## Controles contra fuga de información
- Las estrategias se calibran en un grafo separado (semilla 424242).
- El selector elige una estrategia antes de usar la calidad óptima de la instancia actual.
- El óptimo exacto se usa solo para puntuar, no para seleccionar.
- Todas las estrategias fijas se ejecutan en las mismas instancias.

## Limitaciones
- 8 vértices y 30 grafos son solo un piloto.
- El selector actual es una política simple de historial, no un nuevo algoritmo cuántico.
- Las estrategias se comparan en un presupuesto proxy de evaluaciones; tiempo de pared es secundario.
- El selector puede seleccionar una estrategia mediocre por efectos de calibración.
- Debe ampliarse a más tamaños, semillas, instancias públicas y pruebas estadísticas antes de una conclusión fuerte.
