import json, os, random, platform, sys
from time import perf_counter
from eva_omega.maxcut import exact_maxcut, greedy_maxcut, local_search_maxcut
from eva_omega.selector import AdaptiveSelector

N_GRAPHS = 30
N_VERTICES = 8
EDGE_PROB = 0.35
SEEDS = list(range(1000, 1000 + N_GRAPHS))
ALPHA, GAMMA = 0.70, 0.30  # calidad y número de evaluaciones
STRATEGIES = ["greedy_ascending", "greedy_descending", "local_zero", "local_alternating"]

def make_graph(n, p, seed):
    rng = random.Random(seed)
    edges = []
    for u in range(n):
        for v in range(u + 1, n):
            if rng.random() < p:
                edges.append((u, v, float(rng.randint(1, 10))))
    return edges

def run_strategy(name, n, edges):
    if name == "greedy_ascending":
        return greedy_maxcut(n, edges, list(range(n)))
    if name == "greedy_descending":
        return greedy_maxcut(n, edges, list(reversed(range(n))))
    if name == "local_zero":
        return local_search_maxcut(n, edges, [0] * n)
    if name == "local_alternating":
        return local_search_maxcut(n, edges, [i % 2 for i in range(n)])
    raise ValueError(name)

def loss_for_selection(result, quality_ref, eval_ref):
    qloss = max(0.0, 1.0 - result["cut_value"] / max(quality_ref, 1e-12))
    ecost = min(result["evaluations"] / max(eval_ref, 1), 1.0)
    return ALPHA * qloss + GAMMA * ecost

def stats(values):
    return {
        "mean": sum(values) / len(values) if values else None,
        "median": sorted(values)[len(values)//2] if values else None,
        "min": min(values) if values else None,
        "max": max(values) if values else None
    }

def run():
    n = N_VERTICES
    calibration_edges = make_graph(n, EDGE_PROB, 424242)
    # Calibración separada para impedir usar resultados de test al arrancar.
    calibration_results = {s: run_strategy(s, n, calibration_edges) for s in STRATEGIES}
    cal_quality_ref = max(r["cut_value"] for r in calibration_results.values())
    cal_eval_ref = max(r["evaluations"] for r in calibration_results.values())
    selector = AdaptiveSelector(STRATEGIES)
    for name, result in calibration_results.items():
        selector.update(name, loss_for_selection(result, cal_quality_ref, cal_eval_ref),
                        result["cut_value"], result["evaluations"])
    selector.calibrated = True

    names = STRATEGIES + ["adaptive_eva_omega"]
    rows = {name: [] for name in names}
    per_instance = []
    for seed in SEEDS:
        edges = make_graph(n, EDGE_PROB, seed)
        exact = exact_maxcut(n, edges)
        # Métodos fijos se ejecutan en cada instancia.
        current = {}
        for name in STRATEGIES:
            start = perf_counter()
            result = run_strategy(name, n, edges)
            elapsed = perf_counter() - start
            current[name] = result
            rows[name].append({
                "seed": seed, "cut_value": result["cut_value"],
                "gap": (exact["cut_value"] - result["cut_value"]) / max(exact["cut_value"], 1e-12),
                "evaluations": result["evaluations"], "runtime_seconds": elapsed
            })

        # Selector usa solo el historial anterior y los resultados actuales de la estrategia elegida.
        selected_name = selector.next_strategy()
        # El valor de referencia para loss es el mejor histórico/calibración conocido,
        # no el óptimo exacto de la instancia actual.
        hist_quality = max([r.cumulative_quality / r.observations
                            for r in selector.stats.values() if r.observations] or [1.0])
        hist_eval = max([r.cumulative_evaluations / r.observations
                         for r in selector.stats.values() if r.observations] or [1.0])
        selected = current[selected_name]
        selector_loss = loss_for_selection(selected, hist_quality, hist_eval)
        selector.update(selected_name, selector_loss, selected["cut_value"], selected["evaluations"])
        elapsed = rows[selected_name][-1]["runtime_seconds"]
        rows["adaptive_eva_omega"].append({
            "seed": seed, "selected_strategy": selected_name,
            "cut_value": selected["cut_value"],
            "gap": (exact["cut_value"] - selected["cut_value"]) / max(exact["cut_value"], 1e-12),
            "evaluations": selected["evaluations"], "runtime_seconds": elapsed
        })
        per_instance.append({
            "seed": seed, "exact_optimum": exact["cut_value"],
            "selected_strategy": selected_name,
            "selected_gap": rows["adaptive_eva_omega"][-1]["gap"],
            "fixed_gaps": {name: next(r["gap"] for r in rows[name] if r["seed"] == seed)
                           for name in STRATEGIES}
        })

    summary = {}
    for name, records in rows.items():
        summary[name] = {
            "mean_gap": stats([r["gap"] for r in records]),
            "optimal_rate": sum(1 for r in records if r["gap"] <= 1e-12) / len(records),
            "mean_evaluations": stats([r["evaluations"] for r in records]),
            "mean_runtime_seconds": stats([r["runtime_seconds"] for r in records]),
        }
    best_fixed = min((summary[s]["mean_gap"]["mean"], s) for s in STRATEGIES)
    adaptive_gap = summary["adaptive_eva_omega"]["mean_gap"]["mean"]
    # Bootstrap pareado descriptivo de la diferencia de gap: adaptativo - fijo.
    # Semilla fija para reproducibilidad; no sustituye una preregistración externa.
    rng_boot = random.Random(909090)
    paired_bootstrap = {}
    for fixed_name in STRATEGIES:
        diffs = [item["selected_gap"] - item["fixed_gaps"][fixed_name] for item in per_instance]
        boot_means = []
        for _ in range(5000):
            sample = [diffs[rng_boot.randrange(len(diffs))] for __ in diffs]
            boot_means.append(sum(sample) / len(sample))
        boot_means.sort()
        paired_bootstrap[fixed_name] = {
            "mean_gap_difference_adaptive_minus_fixed": sum(diffs) / len(diffs),
            "bootstrap_95pct_interval": [
                boot_means[int(0.025 * len(boot_means))],
                boot_means[min(int(0.975 * len(boot_means)), len(boot_means)-1)]
            ],
            "interpretation": "Valores negativos favorecen EVA-Ω; valores positivos favorecen el método fijo."
        }
    result = {
        "experiment": "EVA-Ω first scientific objective",
        "hypothesis": "Adaptive selector has mean gap no worse than the best fixed strategy under the defined protocol.",
        "protocol": {
            "graphs": N_GRAPHS, "vertices": N_VERTICES, "edge_probability": EDGE_PROB,
            "seeds": SEEDS, "calibration_seed": 424242, "weights": {"quality": ALPHA, "evaluation_cost": GAMMA},
            "selector": "greedy selection by historical mean loss after separate calibration",
            "quantum_circuit_executed": False
        },
        "environment": {"python": sys.version, "platform": platform.platform()},
        "summary": summary,
        "best_fixed_strategy": best_fixed[1],
        "best_fixed_mean_gap": best_fixed[0],
        "adaptive_mean_gap": adaptive_gap,
        "adaptive_minus_best_fixed_gap": adaptive_gap - best_fixed[0],
        "paired_bootstrap_vs_each_fixed": paired_bootstrap,
        "selector_history": selector.summary(),
        "instances": per_instance,
        "interpretation_warning": "Exploratory small-instance benchmark. Results do not establish universal superiority or quantum advantage."
    }
    out_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "results")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "scientific_benchmark.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)
    print(json.dumps(result, indent=2))
    print(f"\nGuardado en: {out_path}")
    return result

if __name__ == "__main__":
    run()
