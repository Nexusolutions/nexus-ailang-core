# NEXUS Ω / EVA-Ω v0.2 — Primer objetivo científico

## Pregunta experimental
¿Un selector adaptativo sencillo puede igualar o mejorar la calidad de solución frente a una estrategia fija, sin exceder un presupuesto de evaluaciones?

## Hipótesis
H1: en un conjunto reproducible de instancias MaxCut pequeñas, EVA-Ω con selección basada en historial obtiene una calidad media no inferior a la mejor estrategia fija, dentro de un presupuesto de evaluaciones definido previamente.
H0: no alcanza ese umbral o incurre en más coste sin compensación de calidad.

La hipótesis se puede refutar. El benchmark actual no prueba ventaja cuántica: usa métodos clásicos como referencia para validar primero el protocolo experimental.

## Ejecutar
Python 3.10+; biblioteca estándar solamente.

```powershell
python -m unittest discover -s tests -v
python -m experiments.run_scientific_benchmark
```

El benchmark guarda un JSON en `results/scientific_benchmark.json`.

## Diseño del experimento
- 30 grafos ponderados generados con semillas fijas (1000–1029).
- 8 vértices, aristas independientes con probabilidad 0.35 y pesos enteros 1–10.
- Referencia óptima por enumeración exacta, fijando el primer bit para eliminar simetría.
- Métodos comparados: exacto (control/oráculo pequeño), greedy ascendente, greedy descendente, búsqueda local desde todo-cero y búsqueda local desde patrón alternado.
- Selector EVA-Ω: al inicio explora las cinco estrategias candidatas con una instancia de calibración separada; luego escoge la estrategia con menor pérdida histórica media, y actualiza la estimación tras cada instancia.
- Para evitar fuga de información, el selector no usa el óptimo exacto de la instancia actual para escoger estrategia. El óptimo solo se usa después para puntuar resultados.
- Métricas primarias: gap relativo al óptimo, tasa de soluciones óptimas y coste en evaluaciones. Métrica secundaria: tiempo de pared, reportado pero no usado como única evidencia por su variabilidad.
- Semillas, parámetros y código se registran. La comparación es exploratoria; 30 instancias pequeñas no justifican afirmaciones universales.

## Función de pérdida predefinida
Para evaluar estrategias en la selección:
`L = 0.70 * (1 - C / C_ref) + 0.15 * min(N_eval / N_ref, 1)`.
En esta fase se omite el tiempo de pared de la pérdida primaria porque es muy sensible al entorno; se reporta como métrica secundaria. `C_ref` en selección es el mejor valor entre las estrategias conocidas para la instancia de calibración, no el óptimo desconocido en instancias futuras. En evaluación posterior, gap se calcula contra el óptimo exacto solo para medir resultados.

## Interpretación
- EVA-Ω solo se considerará prometedor si mejora la calidad media frente a baselines fijos bajo el mismo presupuesto, y la mejora persiste con otras semillas e instancias.
- El selector adaptativo puede fallar; si lo hace, se informa el resultado y se modifica la hipótesis en un experimento posterior, no se cambia el protocolo retrospectivamente.
- No se ejecuta QAOA ni hardware cuántico en esta versión. El primer objetivo científico valida la capa de selección/benchmark antes de añadir circuitos cuánticos.
