"""Selector adaptativo EVA-Ω para protocolo exploratorio."""
from dataclasses import dataclass, asdict

@dataclass
class StrategyStats:
    name: str
    observations: int = 0
    cumulative_loss: float = 0.0
    cumulative_quality: float = 0.0
    cumulative_evaluations: int = 0

    @property
    def mean_loss(self):
        return self.cumulative_loss / self.observations if self.observations else float("inf")

    def update(self, loss, quality, evaluations):
        self.observations += 1
        self.cumulative_loss += loss
        self.cumulative_quality += quality
        self.cumulative_evaluations += evaluations

    def to_dict(self):
        d = asdict(self)
        d["mean_loss"] = self.mean_loss
        return d

class AdaptiveSelector:
    """
    Explora cada estrategia en la instancia de calibración.
    En las instancias evaluadas elige la menor pérdida media histórica.
    No recibe óptimos exactos de instancias evaluadas para elegir.
    """
    def __init__(self, strategy_names):
        self.stats = {name: StrategyStats(name) for name in strategy_names}
        self.calibrated = False
        self.calibration_order = list(strategy_names)
        self.next_calibration = 0

    def next_strategy(self):
        if not self.calibrated:
            name = self.calibration_order[self.next_calibration]
            self.next_calibration += 1
            if self.next_calibration >= len(self.calibration_order):
                self.calibrated = True
            return name
        # Determinista y auditable: pérdida media; desempate por nombre.
        return min(self.stats.values(), key=lambda s: (s.mean_loss, s.name)).name

    def update(self, name, loss, quality, evaluations):
        self.stats[name].update(loss, quality, evaluations)

    def summary(self):
        return {k: v.to_dict() for k, v in self.stats.items()}
