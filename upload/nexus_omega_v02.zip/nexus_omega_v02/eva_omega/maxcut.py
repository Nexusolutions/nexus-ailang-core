from itertools import product

def validate_graph(n, edges):
    if n < 1:
        raise ValueError("n debe ser >= 1")
    clean = []
    for u, v, w in edges:
        if not (0 <= u < n and 0 <= v < n) or u == v:
            raise ValueError("Arista inválida")
        if w < 0:
            raise ValueError("Los pesos deben ser no negativos")
        clean.append((int(u), int(v), float(w)))
    return clean

def cut_value(bits, edges):
    return sum(w for u, v, w in edges if bits[u] != bits[v])

def exact_maxcut(n, edges):
    edges = validate_graph(n, edges)
    best_bits, best = None, float("-inf")
    evals = 0
    for tail in product((0, 1), repeat=n - 1):
        bits = (0,) + tail
        val = cut_value(bits, edges)
        evals += 1
        if val > best:
            best_bits, best = bits, val
    return {"bits": best_bits, "cut_value": best, "evaluations": evals, "method": "exact"}

def greedy_maxcut(n, edges, order=None):
    edges = validate_graph(n, edges)
    order = list(range(n)) if order is None else list(order)
    if sorted(order) != list(range(n)):
        raise ValueError("order debe ser una permutación de vértices")
    assigned = set()
    bits = [0] * n
    evals = 0
    for v in order:
        s0 = s1 = 0.0
        for u, w in [(u, w) for a, b, w in edges for u in ((b,) if a == v else ((a,) if b == v else ())) ]:
            if u in assigned:
                if bits[u] == 0:
                    s1 += w
                else:
                    s0 += w
        bits[v] = 1 if s1 > s0 else 0
        assigned.add(v)
        evals += 2
    return {"bits": tuple(bits), "cut_value": cut_value(bits, edges), "evaluations": evals, "method": "greedy"}

def local_search_maxcut(n, edges, initial=None, max_passes=100):
    edges = validate_graph(n, edges)
    bits = list(initial if initial is not None else [0] * n)
    if len(bits) != n or any(b not in (0, 1) for b in bits):
        raise ValueError("initial debe tener n bits")
    current = cut_value(bits, edges)
    evals = 1
    for _ in range(max_passes):
        improved = False
        for i in range(n):
            candidate = bits.copy()
            candidate[i] ^= 1
            value = cut_value(candidate, edges)
            evals += 1
            if value > current + 1e-12:
                bits, current = candidate, value
                improved = True
        if not improved:
            break
    return {"bits": tuple(bits), "cut_value": current, "evaluations": evals, "method": "local_search"}
